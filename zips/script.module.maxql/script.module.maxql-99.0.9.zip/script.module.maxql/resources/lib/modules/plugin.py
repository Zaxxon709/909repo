import xbmc
import xbmcplugin
import xbmcaddon
import sys
import os
from .params import Params
from .menu import main_menu
from .maxql_1080p import hd_maxset_1080p
from .maxql_4k import hd_maxset_4k
from .maxql_3d import enable_3d, disable_3d
from .maxql_dv import enable_dv, disable_dv

handle = int(sys.argv[1])

def router(paramstring):

    p = Params(paramstring)
    xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)

    mode = p.get_mode()
    
    xbmcplugin.setContent(handle, 'files')

    if mode is None:
        main_menu()
        
    elif mode == 1:
        hd_maxset_1080p()

    elif mode == 2:
        hd_maxset_4k()

    elif mode == 3:
        enable_dv()

    elif mode == 4:
        disable_dv()

    elif mode == 5:
        enable_3d()

    elif mode == 6:
        disable_3d()

    xbmcplugin.endOfDirectory(handle)
