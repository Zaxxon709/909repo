import xbmc
import xbmcplugin
import xbmcaddon
import sys
import os
from .params import Params
from .menu import main_menu, add_players, remove_players
from .add_players import asgard, base19, ezra, fen, unleashed, ghost, homelander, imdb, scrubs, magicdragon, metv19, moria, nightwing, seren, shadow, thecrew, umbrella, absolution, pov, shazam, quicksilver, genocide, coalition, add_all, add_free, add_fast, add_default_estuary, add_default_oneflix, add_default_switch, add_default_klix, add_default_oneflix, add_default_xlite 
from .remove_players import asgard_rm, base19_rm, ezra_rm, fen_rm, unleashed_rm, ghost_rm, homelander_rm, imdb_rm, scrubs_rm, magicdragon_rm, metv19_rm, moria_rm, nightwing_rm, seren_rm, shadow_rm, thecrew_rm, umbrella_rm, absolution_rm, pov_rm, shazam_rm, quicksilver_rm, genocide_rm, coalition_rm, remove_all

handle = int(sys.argv[1])

def router(paramstring):

    p = Params(paramstring)
    xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)

    mode = p.get_mode()
    
    xbmcplugin.setContent(handle, 'files')

    if mode is None:
        main_menu()

    elif mode == 1:
        add_players()

    elif mode == 2:
        remove_players()

    elif mode == 3:
        asgard()

    elif mode == 4:
        base19()



    elif mode == 6:
        ezra()

    elif mode == 7:
        fen()

    elif mode == 8:
        unleashed()

    elif mode == 9:
        ghost()

    elif mode == 10:
        homelander()

    elif mode == 11:
        imdb()

    elif mode == 12:
        scrubs()

    elif mode == 13:
        magicdragon()

    elif mode == 14:
        metv19()

    elif mode == 15:
        moria()

    elif mode == 16:
        nightwing()

    elif mode == 17:
        seren()

    elif mode == 18:
        shadow()

    elif mode == 19:
        thecrew()

    elif mode == 20:
        umbrella()

    elif mode == 21:
        thepromise()

    elif mode == 22:
        pov()
        
    elif mode == 23:
        shazam()

    elif mode == 24:
        quicksilver()

    elif mode == 25:
        genocide()

    elif mode == 26:
        coalition()
        
    elif mode == 40:
        add_default_xlite()   #Change to build specific player list

    elif mode == 41:
        add_fast()
        
    elif mode == 42:
        add_free()

    elif mode == 43:
        add_all()




    elif mode == 50:
        asgard_rm()

    elif mode == 51:
        base19_rm()



    elif mode == 53:
        ezra_rm()

    elif mode == 54:
        fen_rm()

    elif mode == 55:
        unleashed_rm()

    elif mode == 56:
        ghost_rm()

    elif mode == 57:
        homelander_rm()

    elif mode == 58:
        imdb_rm()

    elif mode == 59:
        scrubs_rm()

    elif mode == 60:
        magicdragon_rm()

    elif mode == 61:
        metv19_rm()

    elif mode == 62:
        moria_rm()

    elif mode == 63:
        nightwing_rm()

    elif mode == 64:
        seren_rm()

    elif mode == 65:
        shadow_rm()

    elif mode == 66:
        thecrew_rm()

    elif mode == 67:
        umbrella_rm()

    elif mode == 68:
        absolution_rm()

    elif mode == 69:
        pov_rm()

    elif mode == 70:
        shazam_rm()

    elif mode == 71:
        quicksilver_rm()

    elif mode == 72:
        genocide_rm()

    elif mode == 73:
        coalition_rm()
        
    elif mode == 80:
        remove_all()

    xbmcplugin.endOfDirectory(handle)
