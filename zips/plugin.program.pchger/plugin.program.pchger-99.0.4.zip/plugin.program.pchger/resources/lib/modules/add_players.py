import os
import shutil
import subprocess
import xbmcgui
import xbmcvfs
import xbmc, xbmcaddon
from pathlib import Path

src_all = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/all_players/')
src_fast = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/fast_players/')
src_free = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/free_players/')
src_top = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/top_players/')
dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
player_path = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
addon_path = xbmcvfs.translatePath('special://home/addons/')

#Player Paths
seren = player_path + 'seren.json'
fen = player_path + 'fen.json'
fen_light = player_path + 'fen_light.json'
ezra = player_path + 'ezra.json'
affenity = player_path + 'affenity.json'
coalition = player_path + 'coalition.json'
pov = player_path + 'pov.json'
umbrella = player_path + 'umbrella.json'
dradis = player_path + 'dradis.json'
taz19 = player_path + 'taz19.json'
shadow = player_path + 'shadow.json'
ghost = player_path + 'ghost.json'
base = player_path + 'base19.json'
unleashed = player_path + 'unleashed.json'
chains = player_path + 'thechains.json'
magicdragon = player_path + 'magicdragon.json'
asgard = player_path + 'asgard.json'
patriot = player_path + 'patriot.json'
black_l = player_path + 'blacklightning.json'
metv19 = player_path + 'metv19.json'
aliunde = player_path + 'aliunde.json'
homelander = player_path + 'homelander.json'
thelab = player_path + 'thelab.json'
quicksilver = player_path + 'quicksilver.json'
genocide = player_path + 'genocide.json'
absolution = player_path + 'absolution.json'
shazam = player_path + 'shazam.json'
thecrew = player_path + 'thecrew.json'
nightwing = player_path + 'nightwing.json'
alvin = player_path + 'alvin.json'
moria = player_path + 'moria.json'
nine = player_path + '9lives.json'
scrubs = player_path + 'scrubsv2.json'
thelabjr = player_path + 'thelabjr.json'
imdb = player_path + 'imdbtrailers.json'

#Add-on Paths
chk_seren = addon_path + 'plugin.video.seren/'
chk_fen = addon_path + 'plugin.video.fen/'
chk_fen_light = addon_path + 'plugin.video.fenlight/'
chk_ezra = addon_path + 'plugin.video.ezra/'
chk_affen = addon_path + 'plugin.video.affenity/'
chk_coal = addon_path + 'plugin.video.coalition/'
chk_pov = addon_path + 'plugin.video.pov/'
chk_umb = addon_path + 'plugin.video.umbrella/'
chk_dradis = addon_path + 'plugin.video.dradis/'
chk_taz = addon_path + 'plugin.video.taz19/'
chk_shadow = addon_path + 'plugin.video.shadow/'
chk_ghost = addon_path + 'plugin.video.ghost/'
chk_base = addon_path + 'plugin.video.base19/'
chk_unleashed = addon_path + 'plugin.video.unleashed/'
chk_chains = addon_path + 'plugin.video.thechains/'
chk_twisted = addon_path + 'plugin.video.twisted/'
chk_md = addon_path + 'plugin.video.magicdragon/'
chk_asgard = addon_path + 'plugin.video.asgard/'
chk_patriot = addon_path + 'plugin.video.patriot/'
chk_blackl = addon_path + 'plugin.video.blacklightning/'
chk_metv = addon_path + 'plugin.video.metv19/'
chk_aliunde = addon_path + 'plugin.video.aliundek19/'
chk_home = addon_path + 'plugin.video.homelander/'
chk_lab = addon_path + 'plugin.video.thelab/'
chk_quick = addon_path + 'plugin.video.quicksilver/'
chk_genocide = addon_path + 'plugin.video.chainsgenocide/'
chk_absol = addon_path + 'plugin.video.absolution/'
chk_shazam = addon_path + 'plugin.video.shazam/'
chk_crew = addon_path + 'plugin.video.thecrew/'
chk_night = addon_path + 'plugin.video.nightwing/'
chk_alvin = addon_path + 'plugin.video.alvin/'
chk_moria = addon_path + 'plugin.video.moria/'
chk_nine = addon_path + 'plugin.video.nine/'
chk_scrubs = addon_path + 'plugin.video.scrubsv2/'
chk_labjr = addon_path + 'plugin.video.thelabjr/'
chk_imdb = addon_path + 'plugin.video.imdbtrailers/'

def add_all():
        try:
                files_dst = os.listdir(dst)
                files_src = os.listdir(src_all)
                for file in files_dst:
                        file_path = os.path.join(dst, file)
                        if os.path.isfile(file_path):
                                os.remove(file_path)
                for fname in files_src:
                        shutil.copy2(os.path.join(src_all,fname), dst)
                        xbmcgui.Dialog().notification('Player Helper', 'All Players Added!',xbmcgui.NOTIFICATION_INFO, 3000)   
        except:
                xbmc.log("Player Changer - Error occurred while adding All Players.", xbmc.LOGINFO)


def add_fast():
        try:
                files_dst = os.listdir(dst)
                files_src = os.listdir(src_fast)
                for file in files_dst:
                        file_path = os.path.join(dst, file)
                        if os.path.isfile(file_path):
                                os.remove(file_path)
                for fname in files_src:
                        shutil.copy2(os.path.join(src_fast,fname), dst)
                        xbmcgui.Dialog().notification('Player Helper', 'Fast Players Added!',xbmcgui.NOTIFICATION_INFO, 3000)
        except:
                xbmc.log("Player Changer - Error occurred while adding Fast Players.", xbmc.LOGINFO)

def add_free():
        try:
                files_dst = os.listdir(dst)
                files_src = os.listdir(src_free)
                for file in files_dst:
                        file_path = os.path.join(dst, file)
                        if os.path.isfile(file_path):
                                os.remove(file_path)
                for fname in files_src:
                        shutil.copy2(os.path.join(src_free,fname), dst)
                        xbmcgui.Dialog().notification('Player Helper', 'Free Players Added!',xbmcgui.NOTIFICATION_INFO, 3000)
        except:
                xbmc.log("Player Changer - Error occurred while adding Free Players.", xbmc.LOGINFO)

def add_top():
        try:
                files_dst = os.listdir(dst)
                files_src = os.listdir(src_top)
                for file in files_dst:
                        file_path = os.path.join(dst, file)
                        if os.path.isfile(file_path):
                                os.remove(file_path)
                for fname in files_src:
                        shutil.copy2(os.path.join(src_top,fname), dst)
                        xbmcgui.Dialog().notification('Player Helper', 'Top Players Added!',xbmcgui.NOTIFICATION_INFO, 3000)
        except:
                xbmc.log("Player Changer - Error occurred while adding Top Players.", xbmc.LOGINFO)
                
class add_ind:
        def seren():
            if xbmcvfs.exists(seren) and xbmcvfs.exists(chk_seren):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_seren):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/seren.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/seren.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('Player Helper', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def fen():
            if xbmcvfs.exists(fen) and xbmcvfs.exists(chk_fen):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_fen):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/fen.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/fen.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def fenlt():
            if xbmcvfs.exists(fen_light) and xbmcvfs.exists(chk_fen_light):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_fen_light):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/fen_light.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/fen_light.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def ezra():
            if xbmcvfs.exists(ezra) and xbmcvfs.exists(chk_ezra):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_ezra):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/ezra.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/ezra.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def affen():
            if xbmcvfs.exists(affenity) and xbmcvfs.exists(chk_affen):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_affen):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/affenity.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/affenity.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def coalition():
            if xbmcvfs.exists(coalition) and xbmcvfs.exists(chk_coal):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_coal):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/coalition.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/coalition.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def pov():
            if xbmcvfs.exists(pov) and xbmcvfs.exists(chk_pov):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_pov):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/pov.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/pov.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def umbrella():
            if xbmcvfs.exists(umbrella) and xbmcvfs.exists(chk_umb):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_umb):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/umbrella.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/umbrella.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def dradis():
            if xbmcvfs.exists(dradis) and xbmcvfs.exists(chk_dradis):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_dradis):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/dradis.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/dradis.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def taz19():
            if xbmcvfs.exists(taz19) and xbmcvfs.exists(chk_taz):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_taz):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/taz19.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/taz19.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def shadow():
            if xbmcvfs.exists(shadow) and xbmcvfs.exists(chk_shadow):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_shadow):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/shadow.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/shadow.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def ghost():
            if xbmcvfs.exists(ghost) and xbmcvfs.exists(chk_ghost):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_ghost):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/ghost.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/ghost.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def base():
            if xbmcvfs.exists(base) and xbmcvfs.exists(chk_base):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_base):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/base19.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/base19.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def unleashed():
            if xbmcvfs.exists(unleashed) and xbmcvfs.exists(chk_unleashed):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_unleashed):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/unleashed.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/unleashed.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def chains():
            if xbmcvfs.exists(chains) and xbmcvfs.exists(chk_chains):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_chains):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/chains.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/chains.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def magicdragon():
            if xbmcvfs.exists(magicdragon) and xbmcvfs.exists(chk_md):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_md):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/magicdragon.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/magicdragon.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)   
                
        def asgard():
            if xbmcvfs.exists(asgard) and xbmcvfs.exists(chk_asgard):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_asgard):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/asgard.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/asgard.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def patriot():
            if xbmcvfs.exists(patriot) and xbmcvfs.exists(chk_patriot):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_patriot):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/patriot.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/patriot.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def black_l():
            if xbmcvfs.exists(black_l) and xbmcvfs.exists(chk_black_l):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_black_l):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/black_l.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/black_l.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def metv19():
            if xbmcvfs.exists(metv) and xbmcvfs.exists(chk_metv):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_metv):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/metv19.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/metv19.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def aliunde():
            if xbmcvfs.exists(aliunde) and xbmcvfs.exists(chk_aliunde):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_aliunde):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/aliunde.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/aliunde.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def homelander():
            if xbmcvfs.exists(homelander) and xbmcvfs.exists(chk_home):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_home):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/homelander.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/homelander.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def thelab():
            if xbmcvfs.exists(thelab) and xbmcvfs.exists(chk_thelab):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_thelab):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/thelab.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thelab.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def quicksilver():
            if xbmcvfs.exists(quicksilver) and xbmcvfs.exists(chk_quick):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_quick):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/quicksilver.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/quicksilver.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def genocide():
            if xbmcvfs.exists(genocide) and xbmcvfs.exists(chk_genocide):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_genocide):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/genocide.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/genocide.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def absolution():
            if xbmcvfs.exists(absolution) and xbmcvfs.exists(chk_absol):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_absol):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/absolution.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/absolution.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def shazam():
            if xbmcvfs.exists(shazam) and xbmcvfs.exists(chk_shazam):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_shazam):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/shazam.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/shazam.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def thecrew():
            if xbmcvfs.exists(thecrew) and xbmcvfs.exists(chk_crew):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_crew):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/thecrew.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thecrew.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def nightwing():
            if xbmcvfs.exists(nightwing) and xbmcvfs.exists(chk_night):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_night):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/nightwing.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/nightwing.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def alvin():
            if xbmcvfs.exists(alvin) and xbmcvfs.exists(chk_alvin):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_alvin):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/alvin.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/alvin.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def moria():
            if xbmcvfs.exists(moria) and xbmcvfs.exists(chk_moria):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_moria):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/moria.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/moria.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def nine():
            if xbmcvfs.exists(nine) and xbmcvfs.exists(chk_nine):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_nine):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/nine.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/nine.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def scrubs():
            if xbmcvfs.exists(scrubs) and xbmcvfs.exists(chk_scrubs):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_scrubs):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/scrubs.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/scrubs.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)

        def thelabjr():
            if xbmcvfs.exists(thelabjr) and xbmcvfs.exists(chk_thelabjr):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_thelabjr):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/thelabjr.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thelabjr.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
                
        def imdb():
            if xbmcvfs.exists(imdb) and xbmcvfs.exists(chk_imdb):
                xbmcgui.Dialog().notification('Player Helper', 'Player Already Added!',xbmcgui.NOTIFICATION_INFO, 3000)
            elif not xbmcvfs.exists(chk_imdb):
                xbmcgui.Dialog().notification('Player Helper', 'Addon Not Installed!',xbmcgui.NOTIFICATION_INFO, 3000)
            else:
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/imdb.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/imdb.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 3000)
