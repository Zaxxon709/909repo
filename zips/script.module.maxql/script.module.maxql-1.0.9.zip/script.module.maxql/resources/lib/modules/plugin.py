import xbmc
import xbmcplugin
import xbmcaddon
import sys
import os
from .params import Params
from .menu import main_menu

from .maxql_4k import hd_maxset_4k
from .maxql_3d import enable_3d, disable_3d
from .maxql_dv import enable_dv, disable_dv

handle = int(sys.argv[1])

def router(paramstring):

    p = Params(paramstring)
    xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)

    mode = p.get_mode()
    
    xbmcplugin.setContent(handle, 'files')

    if mode is None:
        main_menu()
        
    elif mode == 1:
        import maxql_1080p
        maxql_1080p.hd().hd_config

    elif mode == 2:
        import maxql_4k
        maxql_4k.4k().4k_config
        
    elif mode == 3:
        import maxql_dv_enable
        maxql_dv_enable.dv().dv_enable
        
    elif mode == 4:
        import maxql_dv_disable
        maxql_dv_disable.dv().dv_disable

    elif mode == 5:
        import maxql_3d_enable
        maxql_3d_enable.3d.3d_enable

    elif mode == 6:
        import maxql_3d_disable
        maxql_3d_disable.3d.3d_disable

    xbmcplugin.endOfDirectory(handle)
