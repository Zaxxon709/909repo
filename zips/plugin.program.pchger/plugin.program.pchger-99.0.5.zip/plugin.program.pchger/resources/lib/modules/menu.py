import os
import sys
import json
import xbmc
import xbmcplugin
import xbmcvfs
import xbmcgui
from .utils import add_dir

icon_path = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/icons/')
player_path = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
addon_path = xbmcvfs.translatePath('special://home/addons/')

#Icon Paths
addon_fanart = icon_path + 'fanart.jpg'
addon_icon = icon_path + 'pchger.png'
choose_icon = icon_path + 'choose.png'
default_icon = icon_path + 'default.png'
add_icon = icon_path + 'add.png'
remove_icon = icon_path + 'remove.png'
free_icon = icon_path + 'free.png'
seven_icon = icon_path + '709.png'
fast_icon = icon_path + 'fast.png'
seren_icon = icon_path + 'seren.png'
fen_icon = icon_path + 'fen.png'
fen_light_icon = icon_path + 'fen_light.png'
ezra_icon = icon_path + 'ezra.png'
affenity_icon = icon_path + 'affenity.png'
coalition_icon = icon_path + 'coalition.png'
pov_icon = icon_path + 'pov.png'
umbrella_icon = icon_path + 'umbrella.png'
dradis_icon = icon_path + 'dradis.png'
taz19_icon = icon_path + 'taz19.png'
shadow_icon = icon_path + 'shadow.png'
ghost_icon = icon_path + 'ghost.png'
base_icon = icon_path + 'base19.png'
unleashed_icon = icon_path + 'unleashed.png'
chains_icon = icon_path + 'chains.png'
magicdragon_icon = icon_path + 'magicdragon.png'
asgard_icon = icon_path + 'asgard.png'
patriot_icon = icon_path + 'patriot.png'
black_l_icon = icon_path + 'black_l.png'
metv_icon = icon_path + 'metv.png'
aliunde_icon = icon_path + 'aliunde.png'
homelander_icon = icon_path + 'homelander.png'
thelab_icon = icon_path + 'thelab.png'
quicksilver_icon = icon_path + 'quick.png'
genocide_icon = icon_path + 'genocide.png'
absolution_icon = icon_path + 'absolution.png'
shazam_icon = icon_path + 'shazam.png'
thecrew_icon = icon_path + 'thecrew.png'
nightwing_icon = icon_path + 'nightwing.png'
alvin_icon = icon_path + 'alvin.png'
moria_icon = icon_path + 'moria.png'
nine_icon = icon_path + 'nine.png'
scrubs_icon = icon_path + 'scrubs.png'
thelabjr_icon = icon_path + 'thelabjr.png'
imdb_icon = icon_path + 'imdb.png'

#Player Paths
seren = player_path + 'seren.json'
fen = player_path + 'fen.json'
fen_light = player_path + 'fen_light.json'
ezra = player_path + 'ezra.json'
affenity = player_path + 'affenity.json'
coalition = player_path + 'coalition.json'
pov = player_path + 'pov.json'
umbrella = player_path + 'umbrella.json'
dradis = player_path + 'dradis.json'
taz19 = player_path + 'taz19.json'
shadow = player_path + 'shadow.json'
ghost = player_path + 'ghost.json'
base = player_path + 'base19.json'
unleashed = player_path + 'unleashed.json'
chains = player_path + 'thechains.json'
magicdragon = player_path + 'magicdragon.json'
asgard = player_path + 'asgard.json'
patriot = player_path + 'patriot.json'
black_l = player_path + 'blacklightning.json'
metv19 = player_path + 'metv19.json'
aliunde = player_path + 'aliunde.json'
homelander = player_path + 'homelander.json'
thelab = player_path + 'thelab.json'
quicksilver = player_path + 'quicksilver.json'
genocide = player_path + 'genocide.json'
absolution = player_path + 'absolution.json'
shazam = player_path + 'shazam.json'
thecrew = player_path + 'thecrew.json'
nightwing = player_path + 'nightwing.json'
alvin = player_path + 'alvin.json'
moria = player_path + 'moria.json'
nine = player_path + '9lives.json'
scrubs = player_path + 'scrubsv2.json'
thelabjr = player_path + 'thelabjr.json'
imdb = player_path + 'imdbtrailers.json'

#Add-on Paths
chk_seren = addon_path + 'plugin.video.seren/'
chk_fen = addon_path + 'plugin.video.fen/'
chk_fen_light = addon_path + 'plugin.video.fenlight/'
chk_ezra = addon_path + 'plugin.video.ezra/'
chk_affen = addon_path + 'plugin.video.affenity/'
chk_coal = addon_path + 'plugin.video.coalition/'
chk_pov = addon_path + 'plugin.video.pov/'
chk_umb = addon_path + 'plugin.video.umbrella/'
chk_dradis = addon_path + 'plugin.video.dradis/'
chk_taz = addon_path + 'plugin.video.taz19/'
chk_shadow = addon_path + 'plugin.video.shadow/'
chk_ghost = addon_path + 'plugin.video.ghost/'
chk_base = addon_path + 'plugin.video.base/'
chk_unleashed = addon_path + 'plugin.video.unleashed/'
chk_chains = addon_path + 'plugin.video.thechains/'
chk_twisted = addon_path + 'plugin.video.twisted/'
chk_md = addon_path + 'plugin.video.magicdragon/'
chk_asgard = addon_path + 'plugin.video.asgard/'
chk_patriot = addon_path + 'plugin.video.patriot/'
chk_blackl = addon_path + 'plugin.video.blacklightning/'
chk_metv = addon_path + 'plugin.video.metv19/'
chk_aliunde = addon_path + 'plugin.video.aliundek19/'
chk_home = addon_path + 'plugin.video.homelander/'
chk_lab = addon_path + 'plugin.video.thelab/'
chk_quick = addon_path + 'plugin.video.quicksilver/'
chk_genocide = addon_path + 'plugin.video.chainsgenocide/'
chk_absol = addon_path + 'plugin.video.absolution/'
chk_shazam = addon_path + 'plugin.video.shazam/'
chk_crew = addon_path + 'plugin.video.thecrew/'
chk_night = addon_path + 'plugin.video.nightwing/'
chk_alvin = addon_path + 'plugin.video.alvin/'
chk_moria = addon_path + 'plugin.video.moria/'
chk_nine = addon_path + 'plugin.video.nine/'
chk_scrubs = addon_path + 'plugin.video.scrubsv2/'
chk_labjr = addon_path + 'plugin.video.thelabjr/'
chk_imdb = addon_path + 'plugin.video.imdbtrailers/'
chk_tmdbh = addon_path + 'plugin.video.themoviedb.helper/'

add = 'Add'
COLOR1 = f'[COLOR goldenrod]{add}[/COLOR]'
player = 'Player'
COLOR2 = f'[COLOR goldenrod]{player}[/COLOR]'
player_added = '- Added!'
COLOR3 = f'[COLOR green]{player_added}[/COLOR]'
remove = 'Remove'
COLOR4 = f'[COLOR goldenrod]{remove}[/COLOR]'
not_installed = 'Addon Not Installed!'
COLOR5 = f'[COLOR red]{not_installed}[/COLOR]'

handle = int(sys.argv[1])

def main_menu():
    xbmcplugin.setPluginCategory(handle, 'Main Menu')
    
    add_dir('Add Players','',1,add_icon,addon_fanart,isFolder=True)
    add_dir('Remove Players','',2,remove_icon,addon_fanart,isFolder=True)
    
    if not xbmcvfs.exists(chk_tmdbh):
        xbmcgui.Dialog().ok('Player Helper', 'TheMovieDb Helper add-on is not installed! To use the Player Helper add-on, please install TheMovieDb Helper.')

        
    if xbmcvfs.exists(chk_tmdbh) and xbmcvfs.exists(player_path):
        pass
    
    if not xbmcvfs.exists(player_path) and xbmcvfs.exists(chk_tmdbh):
        tmdbh_path = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/')
        if xbmcvfs.exists(tmdbh_path):
            os.mkdir(tmdbh_path)
        if xbmcvfs.exists(player_path):
            os.mkdir(player_path)
    
def add_players_menu():
    xbmcplugin.setPluginCategory(handle, 'Players')

    add_dir('Choose Players to Add','',3,choose_icon,addon_fanart,isFolder=True)
    add_dir('Add All Players','',4,add_icon,addon_fanart,isFolder=False)
    add_dir('Add Fast Players','',5,fast_icon,addon_fanart,isFolder=False)
    add_dir('Add Free Players','',6,free_icon,addon_fanart,isFolder=False)
    add_dir("Add 7o9's Top Picks",'',7,seven_icon,addon_fanart,isFolder=False)


def remove_players_menu():
    xbmcplugin.setPluginCategory(handle, 'Remove Players')

    add_dir('Choose Players to Remove','',8,choose_icon,addon_fanart,isFolder=True)
    add_dir(f'Remove All Players','',9,remove_icon,addon_fanart,isFolder=False)


def add_ind_players():
    xbmcplugin.setPluginCategory(handle, 'Players')

    if xbmcvfs.exists(seren) and xbmcvfs.exists(chk_seren):
            add_dir(f'Seren {COLOR3}','',20,seren_icon,addon_fanart,isFolder=False)
    elif xbmcvfs.exists(chk_seren):
        add_dir(f'{COLOR1} Seren {COLOR2}','',20,seren_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Seren {COLOR5}','',20,seren_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(fen) and xbmcvfs.exists(chk_fen):
        add_dir(f'Fen {COLOR3}','',22,fen_icon,addon_fanart,isFolder=False)       
    elif xbmcvfs.exists(chk_fen):
        add_dir(f'{COLOR1} Fen {COLOR2}','',22,fen_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Fen {COLOR5}','',22,fen_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(fen_light) and xbmcvfs.exists(chk_fen_light):
        add_dir(f'Fen Light {COLOR3}','',23,fen_light_icon,addon_fanart,isFolder=False)
    elif xbmcvfs.exists(chk_fen_light):
        add_dir(f'{COLOR1} Fen Light {COLOR2}','',23,fen_light_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Fen Light {COLOR5}','',23,fen_light_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(ezra) and xbmcvfs.exists(chk_ezra):
         add_dir(f'Ezra {COLOR3}','',24,ezra_icon,addon_fanart,isFolder=False)           
    elif xbmcvfs.exists(chk_ezra):
        add_dir(f'{COLOR1} Ezra {COLOR2}','',24,ezra_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Ezra {COLOR5}','',24,ezra_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(affenity) and xbmcvfs.exists(chk_affen):
        add_dir(f'afFENity {COLOR3}','',25,affenity_icon,addon_fanart,isFolder=False)
    elif xbmcvfs.exists(chk_affen):
        add_dir(f'{COLOR1} afFENity {COLOR2}','',25,affenity_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'afFENity {COLOR5}','',25,affenity_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(coalition) and xbmcvfs.exists(chk_coal):
        add_dir(f'Coalition {COLOR3}','',26,coalition_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_coal):
        add_dir(f'{COLOR1} Coalition {COLOR2}','',26,coalition_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'The Coalition {COLOR5}','',26,coalition_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(pov) and xbmcvfs.exists(chk_pov):
        add_dir(f'POV {COLOR3}','',28,pov_icon,addon_fanart,isFolder=False)           
    elif xbmcvfs.exists(chk_pov):
        add_dir(f'{COLOR1} POV {COLOR2}','',28,pov_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'POV {COLOR5}','',28,pov_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(umbrella) and xbmcvfs.exists(chk_umb):
        add_dir(f'Umbrella {COLOR3}','',30,umbrella_icon,addon_fanart,isFolder=False)           
    elif xbmcvfs.exists(chk_umb):
        add_dir(f'{COLOR1} Umbrella {COLOR2}','',30,umbrella_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Umbrella {COLOR5}','',30,umbrella_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(dradis) and xbmcvfs.exists(chk_dradis):
        add_dir(f'Dradis {COLOR3}','',32,dradis_icon,addon_fanart,isFolder=False)
    elif xbmcvfs.exists(chk_dradis):
        add_dir(f'{COLOR1} Dradis {COLOR2}','',32,dradis_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Dradis {COLOR5}','',32,dradis_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(taz19) and xbmcvfs.exists(chk_taz):
        add_dir(f'Taz19 {COLOR3}','',34,taz19_icon,addon_fanart,isFolder=False)
    elif xbmcvfs.exists(chk_taz):
        add_dir(f'{COLOR1} Taz19 {COLOR2}','',34,taz19_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Taz19 {COLOR5}','',34,taz19_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(shadow) and xbmcvfs.exists(chk_shadow):
        add_dir(f'Shadow {COLOR3}','',36,shadow_icon,addon_fanart,isFolder=False)
    elif xbmcvfs.exists(chk_shadow):
        add_dir(f'{COLOR1} Shadow {COLOR2}','',36,shadow_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Shadow {COLOR5}','',36,shadow_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(ghost) and xbmcvfs.exists(chk_ghost):
        add_dir(f'Ghost {COLOR3}','',38,ghost_icon,addon_fanart,isFolder=False)
    elif xbmcvfs.exists(chk_ghost):
        add_dir(f'{COLOR1} Ghost {COLOR2}','',38,ghost_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Ghost {COLOR5}','',38,ghost_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(base) and xbmcvfs.exists(chk_base):
        add_dir(f'Base {COLOR3}','',40,base_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_base):
        add_dir(f'{COLOR1} Base {COLOR2}','',40,base_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Base {COLOR5}','',40,base_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(unleashed) and xbmcvfs.exists(chk_unleashed):
        add_dir(f'Unleashed {COLOR3}','',42,unleashed_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_unleashed):
        add_dir(f'{COLOR1} Unleased {COLOR2}','',42,unleashed_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Unleased {COLOR5}','',42,unleashed_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(chains) and xbmcvfs.exists(chk_chains):
        add_dir(f'Chain Reaction {COLOR3}','',44,chains_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_chains):
        add_dir(f'{COLOR1} Chain Reaction {COLOR2}','',44,chains_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Chain Reaction {COLOR5}','',44,chains_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(magicdragon) and xbmcvfs.exists(chk_md):
        add_dir(f'Magic Dragon {COLOR3}','',46,magicdragon_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_md):
        add_dir(f'{COLOR1} Magic Dragon {COLOR2}','',46,magicdragon_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Magic Dragon {COLOR5}','',46,magicdragon_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(asgard) and xbmcvfs.exists(chk_asgard):
        add_dir(f'Asgard {COLOR3}','',48,asgard_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_asgard):
        add_dir(f'{COLOR1} Asgard {COLOR2}','',48,asgard_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Asgard {COLOR5}','',48,asgard_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(patriot) and xbmcvfs.exists(chk_patriot):
        add_dir(f'Patriot {COLOR3}','',50,patriot_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_patriot):
        add_dir(f'{COLOR1} Patriot {COLOR2}','',50,patriot_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Patriot {COLOR5}','',50,patriot_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(black_l) and xbmcvfs.exists(chk_blackl):
        add_dir(f'Black Lightning {COLOR3}','',52,black_l_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_blackl):
        add_dir(f'{COLOR1} Black Lightning {COLOR2}','',52,black_l_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Black Lightning {COLOR5}','',52,black_l_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(metv19) and xbmcvfs.exists(chk_metv):
        add_dir(f'M.E.T.V {COLOR3}','',54,metv_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_metv):
        add_dir(f'{COLOR1} M.E.T.V {COLOR2}','',54,metv_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'M.E.T.V {COLOR5}','',54,metv_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(aliunde) and xbmcvfs.exists(chk_aliunde):
            add_dir(f'Aliunde {COLOR3}','',56,aliunde_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_aliunde):
        add_dir(f'{COLOR1} Aliunde {COLOR2}','',56,aliunde_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Aliunde {COLOR5}','',56,aliunde_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(homelander) and xbmcvfs.exists(chk_home):
        add_dir(f'Homelander {COLOR3}','',58,homelander_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_home):
        add_dir(f'{COLOR1} Homelander {COLOR2}','',58,homelander_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Homelander {COLOR5}','',58,homelander_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(thelab) and xbmcvfs.exists(chk_lab):
        add_dir(f'TheLab {COLOR3}','',60,thelab_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_lab):
        add_dir(f'{COLOR1} TheLab {COLOR2}','',60,thelab_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'TheLab {COLOR5}','',60,thelab_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(quicksilver) and xbmcvfs.exists(chk_quick):
        add_dir(f'Quicksilver {COLOR3}','',62,quicksilver_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_quick):
        add_dir(f'{COLOR1} Quicksilver {COLOR2}','',62,quicksilver_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Quicksilver {COLOR5}','',62,quicksilver_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(genocide) and xbmcvfs.exists(chk_genocide):
        add_dir(f'Chains Genocide {COLOR3}','',64,genocide_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_genocide):
        add_dir(f'{COLOR1} Chains Genocide {COLOR2}','',64,genocide_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Chains Genocide {COLOR5}','',64,genocide_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(absolution) and xbmcvfs.exists(chk_absol):
        add_dir(f'Absolution {COLOR3}','',66,absolution_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_absol):
        add_dir(f'{COLOR1} Absolution {COLOR2}','',66,absolution_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Absolution {COLOR5}','',66,absolution_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(shazam) and xbmcvfs.exists(chk_shazam):
        add_dir(f'Shazam {COLOR3}','',68,shazam_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_shazam):
        add_dir(f'{COLOR1} Shazam {COLOR2}','',68,shazam_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Shazam {COLOR5}','',68,shazam_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(thecrew) and xbmcvfs.exists(chk_crew):
        add_dir(f'The Crew {COLOR3}','',70,thecrew_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_crew):
        add_dir(f'{COLOR1} The Crew {COLOR2}','',70,thecrew_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'The Crew {COLOR5}','',70,thecrew_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(nightwing) and xbmcvfs.exists(chk_night):
        add_dir(f'Nightwing {COLOR3}','',72,nightwing_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_night):
        add_dir(f'{COLOR1} Nightwing {COLOR2}','',72,nightwing_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Nightwing {COLOR5}','',72,nightwing_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(alvin) and xbmcvfs.exists(chk_alvin):
        add_dir(f'Alvin {COLOR3}','',74,alvin_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_alvin):
        add_dir(f'{COLOR1} Alvin {COLOR2}','',74,alvin_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Alvin {COLOR5}','',74,alvin_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(moria) and xbmcvfs.exists(chk_moria):
        add_dir(f'Moria {COLOR3}','',76,moria_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_moria):
        add_dir(f'{COLOR1} Moria {COLOR2}','',76,moria_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Moria {COLOR5}','',76,moria_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(nine) and xbmcvfs.exists(chk_nine):
        add_dir(f'Nine Lives {COLOR3}','',78,nine_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_nine):
        add_dir(f'{COLOR1} Nine Lives {COLOR2}','',78,nine_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Nine Lives {COLOR5}','',78,nine_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(scrubs) and xbmcvfs.exists(chk_scrubs):
        add_dir(f'Scrubs V2 {COLOR3}','',80,scrubs_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_scrubs):
        add_dir(f'{COLOR1} Scrubs V2 {COLOR2}','',80,scrubs_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'Scrubs V2 {COLOR5}','',80,scrubs_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(thelabjr) and xbmcvfs.exists(chk_labjr):
        add_dir(f'TheLabjr {COLOR3}','',82,thelabjr_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_labjr):
        add_dir(f'{COLOR1} TheLabjr {COLOR2}','',82,thelabjr_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'TheLabjr {COLOR5}','',82,thelabjr_icon,addon_fanart,isFolder=False)

    if xbmcvfs.exists(imdb) and xbmcvfs.exists(chk_imdb):
        add_dir(f'IMDb Trailers {COLOR3}','',84,imdb_icon,addon_fanart,isFolder=False)            
    elif xbmcvfs.exists(chk_imdb):
        add_dir(f'{COLOR1} IMDd Trailers {COLOR2}','',84,imdb_icon,addon_fanart,isFolder=False)
    else:
        add_dir(f'IMDd Trailers {COLOR5}','',84,imdb_icon,addon_fanart,isFolder=False)

            

def remove_ind_players():

    xbmcplugin.setPluginCategory(handle, 'Remove Players')
    
    src = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
    chk_empty = os.listdir(src)
    
    if len(chk_empty) == 0:
        xbmcgui.Dialog().notification('TMDbH', 'No Players to Remove!',xbmcgui.NOTIFICATION_INFO, 1000)
        xbmc.executebuiltin('Action(back)')
    else:
        if xbmcvfs.exists(seren) and xbmcvfs.exists(chk_seren):
            add_dir(f'{COLOR4} Seren {COLOR2}','',100,seren_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(fen) and xbmcvfs.exists(chk_fen):
            add_dir(f'{COLOR4} Fen {COLOR2}','',102,fen_icon,addon_fanart,isFolder=False)
        else:
            pass

        if xbmcvfs.exists(fen_light) and xbmcvfs.exists(chk_fen_light):
            add_dir(f'{COLOR4} Fen Light {COLOR2}','',103,fen_light_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(ezra) and xbmcvfs.exists(chk_ezra):
            add_dir(f'{COLOR4} Ezra {COLOR2}','',104,ezra_icon,addon_fanart,isFolder=False)
        else:
            pass

        if xbmcvfs.exists(affenity) and xbmcvfs.exists(chk_affen):
            add_dir(f'{COLOR4} afFENity {COLOR2}','',105,affenity,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(coalition) and xbmcvfs.exists(chk_coal):
            add_dir(f'{COLOR4} Coalition {COLOR2}','',106,coalition_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(pov) and xbmcvfs.exists(chk_pov):
            add_dir(f'{COLOR4} POV {COLOR2}','',108,pov_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(umbrella) and xbmcvfs.exists(chk_umb):
            add_dir(f'{COLOR4} Umbrella {COLOR2}','',110,umbrella_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(dradis) and xbmcvfs.exists(chk_dradis):
            add_dir(f'{COLOR4} Dradis {COLOR2}','',112,dradis_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(taz19) and xbmcvfs.exists(chk_taz):
            add_dir(f'{COLOR4} Taz19 {COLOR2}','',114,taz19_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(shadow) and xbmcvfs.exists(chk_shadow):
            add_dir(f'{COLOR4} Shadow {COLOR2}','',116,shadow_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(ghost) and xbmcvfs.exists(chk_ghost):
            add_dir(f'{COLOR4} Ghost {COLOR2}','',118,ghost_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(base) and xbmcvfs.exists(chk_base):
            add_dir(f'{COLOR4} Base {COLOR2}','',120,base_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(unleashed) and xbmcvfs.exists(chk_unleashed):
            add_dir(f'{COLOR4} Unleashed {COLOR2}','',122,unleashed_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(chains) and xbmcvfs.exists(chk_chains):
            add_dir(f'{COLOR4} Chain Reaction {COLOR2}','',124,chains_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(magicdragon) and xbmcvfs.exists(chk_md):
            add_dir(f'{COLOR4} Magic Dragon {COLOR2}','',126,magicdragon_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(asgard) and xbmcvfs.exists(chk_asgard):
            add_dir(f'{COLOR4} Asgard {COLOR2}','',128,asgard_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(patriot) and xbmcvfs.exists(chk_patriot):
            add_dir(f'{COLOR4} Patriot {COLOR2}','',130,patriot_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(black_l) and xbmcvfs.exists(chk_blackl):
            add_dir(f'{COLOR4} Black Lightning {COLOR2}','',132,black_l_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(metv19) and xbmcvfs.exists(chk_metv):
            add_dir(f'{COLOR4} M.E.T.V {COLOR2}','',134,metv_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(aliunde) and xbmcvfs.exists(chk_aliunde):
            add_dir(f'{COLOR4} Aliunde {COLOR2}','',136,aliunde_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(homelander) and xbmcvfs.exists(chk_home):
            add_dir(f'{COLOR4} Homelander {COLOR2}','',138,homelander_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(thelab) and xbmcvfs.exists(chk_lab):
            add_dir(f'{COLOR4} TheLab {COLOR2}','',140,thelab_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(quicksilver) and xbmcvfs.exists(chk_quick):
            add_dir(f'{COLOR4} Quicksilver {COLOR2}','',142,quicksilver_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(genocide) and xbmcvfs.exists(chk_genocide):
            add_dir(f'{COLOR4} Chains Genocide {COLOR2}','',144,genocide_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(absolution) and xbmcvfs.exists(chk_absol):
            add_dir(f'{COLOR4} Absolution {COLOR2}','',146,absolution_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(shazam) and xbmcvfs.exists(chk_shazam):
            add_dir(f'{COLOR4} Shazam {COLOR2}','',148,shazam_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(thecrew) and xbmcvfs.exists(chk_crew):
            add_dir(f'{COLOR4} The Crew {COLOR2}','',150,thecrew_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(nightwing) and xbmcvfs.exists(chk_night):
            add_dir(f'{COLOR4} Nightwing {COLOR2}','',152,nightwing_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(alvin) and xbmcvfs.exists(chk_alvin):
            add_dir(f'{COLOR4} Alvin {COLOR2}','',154,alvin_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(moria) and xbmcvfs.exists(chk_moria):
            add_dir(f'{COLOR4} Moria {COLOR2}','',156,moria_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(nine) and xbmcvfs.exists(chk_nine):
            add_dir(f'{COLOR4} Nine Lives {COLOR2}','',158,nine_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(scrubs) and xbmcvfs.exists(chk_scrubs):
            add_dir(f'{COLOR4} Scrubs V2 {COLOR2}','',160,scrubs_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(thelabjr) and xbmcvfs.exists(chk_labjr):
            add_dir(f'{COLOR4} TheLabjr {COLOR2}','',162,thelabjr_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(imdb) and xbmcvfs.exists(chk_imdb):
            add_dir(f'{COLOR4} IMDb Trailers {COLOR2}','',164,imdb_icon,addon_fanart,isFolder=False)
        else:
            pass
