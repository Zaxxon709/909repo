import installer
import xbmcvfs
import xbmcaddon

settings = xbmcvfs.translatePath('special://userdata/addon_data/script.module.autoinstall/settings.xml')
                                 
def main():
    installer.Installer().create_folder(installer.Installer().addon_data)

    if xbmcvfs.exists(settings):

        if xbmcaddon.Addon().getSetting("first_run") == 'true':
            xbmc.sleep(10000)
            first_run = installer.Installer().dialog_yesno("This is your first time running the build! There are no pre-installed video add-ons included in this build. Choose 'Create List' to create your custom list of video add-ons to install.", yeslabel="Create List")
            if first_run:
                installer.Installer().get_addon_list()
                xbmcaddon.Addon().setSetting("first_run", "false")
            elif first_run:
                exit
            
        elif xbmcaddon.Addon().getSetting("activate_installer") == 'true':
            installer.Installer().installer()

        elif xbmcaddon.Addon().getSetting("list_creator") == 'true':
            installer.Installer().get_addon_list()

if __name__ == "__main__":
    main()
