import sys
import json
import xbmc
import xbmcplugin
from .utils import add_dir

addon_fanart = 'special://home/addons/script.module.pchger/icons/fanart.jpg'
default_icon = 'special://home/addons/script.module.pchger/icons/default.png'
add_icon = 'special://home/addons/script.module.pchger/icons/add.png'
remove_icon = 'special://home/addons/script.module.pchger/icons/remove.png'
free_icon = 'special://home/addons/script.module.pchger/icons/free.png'
fast_icon = 'special://home/addons/script.module.pchger/icons/fast.png'
asgard_icon = 'special://home/addons/script.module.pchger/icons/asgard.png'
base19_icon = 'special://home/addons/script.module.pchger/icons/base19.png'
ezra_icon = 'special://home/addons/script.module.pchger/icons/ezra.png'
fen_icon = 'special://home/addons/script.module.pchger/icons/fen.png'
pov_icon = 'special://home/addons/script.module.pchger/icons/pov.png'
coalition_icon = 'special://home/addons/script.module.pchger/icons/coalition.png'
unleashed_icon = 'special://home/addons/script.module.pchger/icons/unleashed.png'
ghost_icon = 'special://home/addons/script.module.pchger/icons/ghost.png'
homelander_icon = 'special://home/addons/script.module.pchger/icons/homelander.png'
imdb_icon = 'special://home/addons/script.module.pchger/icons/imdb.png'
scrubs_icon = 'special://home/addons/script.module.pchger/icons/scrubs.png'
magicdragon_icon = 'special://home/addons/script.module.pchger/icons/magicdragon.png'
metv_icon = 'special://home/addons/script.module.pchger/icons/metv.png'
moria_icon = 'special://home/addons/script.module.pchger/icons/moria.png'
nightwing_icon = 'special://home/addons/script.module.pchger/icons/nightwing.png'
seren_icon = 'special://home/addons/script.module.pchger/icons/seren.png'
shadow_icon = 'special://home/addons/script.module.pchger/icons/shadow.png'
thecrew_icon = 'special://home/addons/script.module.pchger/icons/thecrew.png'
umbrella_icon = 'special://home/addons/script.module.pchger/icons/umbrella.png'
absolution_icon = 'special://home/addons/script.module.pchger/icons/absolution.png'
shazam_icon = 'special://home/addons/script.module.pchger/icons/shazam.png'
quicksilver_icon = 'special://home/addons/script.module.pchger/icons/quick.png'
genocide_icon = 'special://home/addons/script.module.pchger/icons/genocide.png'

handle = int(sys.argv[1])

def main_menu():
    xbmcplugin.setPluginCategory(handle, 'Main Menu')
    
    add_dir('Add TMDb Helper Players','',1,add_icon,addon_fanart,isFolder=True)

    add_dir('Remove TMDB Helper Players','',2,remove_icon,addon_fanart,isFolder=True)

def add_players():
    xbmcplugin.setPluginCategory(handle, 'Add Players')
    
    add_dir('Add Asgard Player','',3,asgard_icon,addon_fanart,isFolder=False)

    add_dir('Add Base19 Player','',4,base19_icon,addon_fanart,isFolder=False)

    add_dir('Add Ezra Player','',6,ezra_icon,addon_fanart,isFolder=False)

    add_dir('Add Fen Player','',7,fen_icon,addon_fanart,isFolder=False)
    
    add_dir('Add Unleashed Player','',8,unleashed_icon,addon_fanart,isFolder=False)

    add_dir('Add Ghost Player','',9,ghost_icon,addon_fanart,isFolder=False)

    add_dir('Add Homelander Player','',10,homelander_icon,addon_fanart,isFolder=False)

    add_dir('Add IMDb Trailers Player','',11,imdb_icon,addon_fanart,isFolder=False)

    add_dir('Add Scrubs V2 Player','',12,scrubs_icon,addon_fanart,isFolder=False)

    add_dir('Add Magic Dragon Player','',13,magicdragon_icon,addon_fanart,isFolder=False)   

    add_dir('Add M.E.T.V Player','',14,metv_icon,addon_fanart,isFolder=False)

    add_dir('Add Moria Player','',15,moria_icon,addon_fanart,isFolder=False)

    add_dir('Add Nightwing Player','',16,nightwing_icon,addon_fanart,isFolder=False)

    add_dir('Add Seren Player','',17,seren_icon,addon_fanart,isFolder=False)

    add_dir('Add Shadow Player','',18,shadow_icon,addon_fanart,isFolder=False)

    add_dir('Add The Crew Player','',19,thecrew_icon,addon_fanart,isFolder=False)

    add_dir('Add Umbrella Player','',20,umbrella_icon,addon_fanart,isFolder=False)
    
    add_dir('Add Absolution Player','',21,absolution_icon,addon_fanart,isFolder=False)

    add_dir('Add POV Player','',22,pov_icon,addon_fanart,isFolder=False)

    add_dir('Add Shazam Player','',23,shazam_icon,addon_fanart,isFolder=False)

    add_dir('Add Quicksilver Player','',24,quicksilver_icon,addon_fanart,isFolder=False)

    add_dir('Add Chains Genocide Player','',25,genocide_icon,addon_fanart,isFolder=False)

    add_dir('Add Coalition Player','',26,coalition_icon,addon_fanart,isFolder=False)

    add_dir('Add Default Build Players','',40,default_icon,addon_fanart,isFolder=False)

    add_dir('Add Fast Scraper Players','',41,fast_icon,addon_fanart,isFolder=False)

    add_dir('Add Non-Debrid Players','',42,free_icon,addon_fanart,isFolder=False)

    add_dir('Add All Players','',43,add_icon,addon_fanart,isFolder=False)

def remove_players():
    xbmcplugin.setPluginCategory(handle, 'Remove Players')
    
    add_dir('Remove Asgard Player','',50,asgard_icon,addon_fanart,isFolder=False)

    add_dir('Remove Base19 Player','',51,base19_icon,addon_fanart,isFolder=False)

    add_dir('Remove Ezra Player','',53,ezra_icon,addon_fanart,isFolder=False)

    add_dir('Remove Fen Player','',54,fen_icon,addon_fanart,isFolder=False)
    
    add_dir('Remove Unleashed Player','',55,unleashed_icon,addon_fanart,isFolder=False)

    add_dir('Remove Ghost Player','',56,ghost_icon,addon_fanart,isFolder=False)

    add_dir('Remove Homelander Player','',57,homelander_icon,addon_fanart,isFolder=False)

    add_dir('Remove IMDb Trailers Player','',58,imdb_icon,addon_fanart,isFolder=False)

    add_dir('Remove Scrubs V2 Player','',59,scrubs_icon,addon_fanart,isFolder=False)

    add_dir('Remove Magic Dragon Player','',60,magicdragon_icon,addon_fanart,isFolder=False)   

    add_dir('Remove M.E.T.V Player','',61,metv_icon,addon_fanart,isFolder=False)

    add_dir('Remove Moria Player','',62,moria_icon,addon_fanart,isFolder=False)

    add_dir('Remove Nightwing Player','',63,nightwing_icon,addon_fanart,isFolder=False)

    add_dir('Remove Seren Player','',64,seren_icon,addon_fanart,isFolder=False)

    add_dir('Remove Shadow Player','',65,shadow_icon,addon_fanart,isFolder=False)

    add_dir('Remove The Crew Player','',66,thecrew_icon,addon_fanart,isFolder=False)

    add_dir('Remove Umbrella Player','',67,umbrella_icon,addon_fanart,isFolder=False)

    add_dir('Remove Absolution Player','',68,absolution_icon,addon_fanart,isFolder=False)

    add_dir('Remove The POV Player','',69,pov_icon,addon_fanart,isFolder=False)

    add_dir('Remove Shazam Player','',70,shazam_icon,addon_fanart,isFolder=False)

    add_dir('Remove Quicksilver Player','',71,quicksilver_icon,addon_fanart,isFolder=False)

    add_dir('Remove Chains Genocide Player','',72,genocide_icon,addon_fanart,isFolder=False)

    add_dir('Remove Coalition Player','',73,coalition_icon,addon_fanart,isFolder=False)

    add_dir('Remove All Players','',80,remove_icon,addon_fanart,isFolder=False)
