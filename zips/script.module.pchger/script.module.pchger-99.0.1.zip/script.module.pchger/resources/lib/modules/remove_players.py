import os
import shutil
import subprocess
import xbmcgui
import xbmcvfs
import xbmc, xbmcaddon

def asgard_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/130_direct.asgard.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/130_direct.asgard.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
	
def base19_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/160_direct.base19.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/160_direct.base19.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def ezra_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/30_direct.ezra.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/30_direct.ezra.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def fen_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/20_direct.fen.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/20_direct.fen.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def coalition_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/35_direct.coalition.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/35_direct.coalition.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
	
def unleashed_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/120_direct.unleashed.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/120_direct.unleashed.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def ghost_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/100_direct.ghost.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/100_direct.ghost.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def homelander_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/50_homelander.select.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/50_homelander.select.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def imdb_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/250_imdbtrailers.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/250_imdbtrailers.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
	
def scrubs_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/170_direct.scrubsv2.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/170_direct.scrubsv2.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def magicdragon_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/140_direct.magicdragon.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/140_direct.magicdragon.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
	
def metv19_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/150_direct.metv19.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/150_direct.metv19.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def moria_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/80_direct.moria.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/80_direct.moria.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def nightwing_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/70_direct.nightwing.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/70_direct.nightwing.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def seren_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/10_seren.select.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/10_seren.select.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def shadow_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/90_direct.shadow.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/90_direct.shadow.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def thecrew_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/60_direct.thecrew.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/60_direct.thecrew.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def umbrella_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/40_umbrella.select.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/40_umbrella.select.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def absolution_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/55_direct.absolution.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/55_direct.absolution.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def pov_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/25_direct.pov.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/25_direct.pov.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def shazam_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/190_shazam.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/190_shazam.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def quicksilver_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/75_quicksilver.select.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/75_quicksilver.select.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

def genocide_rm():
        player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/195_genocide.select.json')
       
        if xbmcvfs.exists(player_file):
                file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/195_genocide.select.json')
                os.remove(file)
                xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)


def remove_all():
        asgard_rm()
        base19_rm()
        ezra_rm()
        fen_rm()
        unleashed_rm()
        ghost_rm()
        homelander_rm()
        absolution_rm()
        imdb_rm()
        scrubs_rm()
        magicdragon_rm()
        metv19_rm()
        moria_rm()
        nightwing_rm()
        seren_rm()
        shadow_rm()
        thecrew_rm()
        umbrella_rm()
        pov_rm()
        shazam_rm()
        quicksilver_rm()
        genocide_rm()
        coalition_rm()
