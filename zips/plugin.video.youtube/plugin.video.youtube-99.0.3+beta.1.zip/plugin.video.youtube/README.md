
![](https://github.com/anxdpanic/plugin.video.youtube/raw/master/resources/media/icon.png)

[![Build Status](https://img.shields.io/endpoint.svg?url=https%3A%2F%2Factions-badge.atrox.dev%2Fanxdpanic%2Fplugin.video.youtube%2Fbadge&logo=none)](https://actions-badge.atrox.dev/anxdpanic/plugin.video.youtube/goto)
![License](https://img.shields.io/badge/license-GPL--2.0--only-success.svg)
![Kodi Version](https://img.shields.io/badge/kodi-nexus%2B-success.svg)
![Contributors](https://img.shields.io/github/contributors/anxdpanic/plugin.video.youtube.svg)

## Links

* [YouTube](http://www.youtube.com)
* [Support thread](https://ytaddon.page.link/forum)
* [Wiki](https://github.com/anxdpanic/plugin.video.youtube/wiki)

---

![](https://i.imgur.com/fzPmDDJ.gif)
