import os
import shutil
import subprocess
import xbmcgui
import xbmcvfs
import xbmc, xbmcaddon
from .remove_players import asgard_rm, base19_rm, ezra_rm, fen_rm, coalition_rm, unleashed_rm, ghost_rm, homelander_rm, imdb_rm, scrubs_rm, magicdragon_rm, metv19_rm, moria_rm, nightwing_rm, seren_rm, shadow_rm, thecrew_rm, umbrella_rm, absolution_rm, pov_rm, shazam_rm, quicksilver_rm, genocide_rm

def asgard():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/130_direct.asgard.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/130_direct.asgard.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
	
def base19():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/160_direct.base19.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/160_direct.base19.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def ezra():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/30_direct.ezra.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/30_direct.ezra.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def fen():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/20_direct.fen.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/20_direct.fen.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def coalition():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/35_direct.coalition.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/35_direct.coalition.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
	
def unleashed():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/120_direct.unleashed.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/120_direct.unleashed.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def ghost():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/100_direct.ghost.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/100_direct.ghost.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def homelander():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/50_homelander.select.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/50_homelander.select.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def imdb():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/250_imdbtrailers.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/250_imdbtrailers.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
	
def scrubs():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/170_direct.scrubsv2.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/170_direct.scrubsv2.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def magicdragon():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/140_direct.magicdragon.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/140_direct.magicdragon.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
	
def metv19():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/150_direct.metv19.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/150_direct.metv19.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def moria():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/80_direct.moria.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/80_direct.moria.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def nightwing():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/70_direct.nightwing.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/70_direct.nightwing.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def seren():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/10_seren.select.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/10_seren.select.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def shadow():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/90_direct.shadow.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/90_direct.shadow.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def thecrew():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/60_direct.thecrew.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/60_direct.thecrew.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def umbrella():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/40_umbrella.select.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/40_umbrella.select.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def absolution():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/55_direct.absolution.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/55_direct.absolution.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def pov():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/25_direct.pov.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/25_direct.pov.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def shazam():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/190_shazam.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/190_shazam.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def quicksilver():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/75_quicksilver.select.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/75_quicksilver.select.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

def genocide():
        src = xbmcvfs.translatePath('special://home/addons/script.module.pchger/players/195_genocide.select.json')
        dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/195_genocide.select.json')
        
        shutil.copyfile(src, dst)
        xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)


def add_all():
        asgard()
        base19()
        ezra()
        fen()
        coalition()
        unleashed()
        ghost()
        homelander()
        imdb()
        scrubs()
        magicdragon()
        metv19()
        moria()
        nightwing()
        seren()
        shadow()
        thecrew()
        umbrella()
        absolution()
        pov()
        shazam()
        quicksilver()
        genocide()

def add_free():
        asgard_rm()
        base19_rm()
        ezra_rm()
        unleashed_rm()
        magicdragon_rm()
        metv19_rm()
        moria_rm()
        nightwing()
        shadow_rm()
        absolution()
        pov_rm()
        scrubs()
        fen_rm()
        coalition_rm()
        ghost_rm()
        homelander()
        imdb()
        seren_rm()
        thecrew()
        umbrella_rm()
        shazam()
        quicksilver()
        genocide()
        
def add_fast():
        asgard_rm()
        base19_rm()
        ezra()
        unleashed_rm()
        magicdragon_rm()
        metv19_rm()
        moria_rm()
        nightwing_rm()
        shadow_rm()
        absolution_rm()
        pov()
        scrubs_rm()
        fen()
        coalition()
        ghost_rm()
        homelander_rm()
        imdb()
        seren()
        thecrew_rm()
        umbrella()
        shazam_rm()
        quicksilver_rm()
        genocide_rm()
        
def add_default_estuary():
        asgard_rm()
        base19_rm()
        ezra_rm()
        unleashed_rm()
        magicdragon_rm()
        metv19_rm()
        moria_rm()
        nightwing_rm()
        shadow_rm()
        absolution_rm()
        pov()
        scrubs_rm()
        fen_rm()
        coalition_rm()
        ghost_rm()
        homelander()
        imdb()
        seren_rm()
        thecrew_rm()
        umbrella()
        shazam_rm()
        quicksilver_rm()
        genocide_rm()

def add_default_oneflix():
        asgard_rm()
        base19_rm()
        ezra_rm()
        unleashed_rm()
        magicdragon_rm()
        metv19_rm()
        moria_rm()
        nightwing()
        shadow_rm()
        absolution()
        pov()
        scrubs()
        fen()
        coalition()
        ghost()
        homelander()
        imdb()
        seren()
        thecrew()
        umbrella()
        shazam()
        quicksilver()
        genocide()
        
def add_default_switch():
        asgard_rm()
        base19_rm()
        ezra_rm()
        unleashed_rm()
        magicdragon_rm()
        metv19_rm()
        moria_rm()
        nightwing_rm()
        shadow_rm()
        absolution()
        pov_rm()
        scrubs()
        fen()
        coalition()
        ghost()
        homelander()
        imdb()
        seren()
        thecrew()
        umbrella()
        shazam_rm()
        quicksilver_rm()
        genocide_rm()
        
def add_default_klix():
        asgard_rm()
        base19_rm()
        ezra_rm()
        unleashed_rm()
        magicdragon_rm()
        metv19_rm()
        moria_rm()
        nightwing_rm()
        shadow_rm()
        absolution_rm()
        pov_rm()
        fen()
        coalition()
        ghost_rm()
        homelander()
        imdb()
        seren()
        thecrew_rm()
        umbrella()
        shazam_rm()
        quicksilver_rm()
        genocide_rm()
        
def add_default_xlite():
        asgard_rm()
        base19_rm()
        ezra_rm()
        unleashed_rm()
        magicdragon_rm()
        metv19_rm()
        moria_rm()
        nightwing_rm()
        shadow_rm()
        absolution_rm()
        pov_rm()
        scrubs_rm()
        fen()
        coalition()
        ghost()
        homelander()
        imdb()
        seren()
        thecrew()
        umbrella()
        shazam_rm()
        quicksilver_rm()
        genocide_rm()
