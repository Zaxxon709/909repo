import xbmc
import xbmcplugin
import xbmcaddon
import sys
import os
from .params import Params

handle = int(sys.argv[1])

def router(paramstring):

    p = Params(paramstring)
    xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)

    mode = p.get_mode()
    
    xbmcplugin.setContent(handle, 'files')

    if mode is None:
        main_menu()
        
    elif mode == 1:
        from resources.lib.modules import installer
        installer.Installer().get_addon_list()

    elif mode == 2:
        from resources.lib.modules import installer
        installer.Installer().installer()
        
    xbmcplugin.endOfDirectory(handle)
